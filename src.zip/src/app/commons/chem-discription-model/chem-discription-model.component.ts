import { Component } from '@angular/core';

@Component({
  selector: 'app-Chem_Robotics_DescriptionModal',
  standalone: true,
  imports: [],
  templateUrl: './chem-discription-model.component.html',
  styleUrl: './chem-discription-model.component.css'
})
export class ChemDiscriptionModelComponent {

}
