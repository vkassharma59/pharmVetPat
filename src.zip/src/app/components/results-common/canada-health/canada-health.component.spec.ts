import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CanadaHealthComponent } from './canada-health.component';

describe('CanadaHealthComponent', () => {
  let component: CanadaHealthComponent;
  let fixture: ComponentFixture<CanadaHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CanadaHealthComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CanadaHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
